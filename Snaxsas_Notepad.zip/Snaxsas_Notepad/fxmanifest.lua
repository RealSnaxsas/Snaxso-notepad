fx_version  'cerulean'
game  'gta5'
lua54 'yes'


author 'Snaxsas'
description 'Snaxso Notepad'
version '2.0.0'


client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

shared_scripts {
  'config.lua',
  '@ox_lib/init.lua'
}

files {
  'locales/*.json'
}

dependencies {
  'ox_lib',
  'ox_inventory',
}
